package com.example.urgencepompiers

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.database.Cursor
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telephony.SmsManager
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class MainActivity : AppCompatActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var sharedPreferences: SharedPreferences

    companion object {
        private const val REQUEST_SELECT_CONTACT = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        sharedPreferences = getSharedPreferences("UrgencePrefs", Context.MODE_PRIVATE)

        findViewById<Button>(R.id.btnCall).setOnClickListener { callEmergency() }
        findViewById<Button>(R.id.btnSms).setOnClickListener { sendEmergencySMS() }
        findViewById<Button>(R.id.btnCamera).setOnClickListener { openCamera() }
        findViewById<Button>(R.id.btnSelectContact).setOnClickListener { selectContact() }

        if (sharedPreferences.getString("contactNumber", null) == null) {
            selectContact()
        }
    }

    private fun callEmergency() {
        val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:18"))
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            startActivity(callIntent)
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), 1)
        }
    }

    private fun sendEmergencySMS() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.ACCESS_FINE_LOCATION), 2)
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                val message = "🚨 ALERTE D'URGENCE 🚨\nLes pompiers ont été contactés.\nLocalisation: ${it.latitude}, ${it.longitude}, Altitude: ${it.altitude}m"
                val emergencyNumber = "112"
                val contactNumber = sharedPreferences.getString("contactNumber", null)

                try {
                    val smsManager = SmsManager.getDefault()
                    smsManager.sendTextMessage(emergencyNumber, null, message, null, null)
                    Toast.makeText(this, "Alerte envoyée aux pompiers !", Toast.LENGTH_SHORT).show()

                    if (contactNumber != null) {
                        smsManager.sendTextMessage(contactNumber, null, message, null, null)
                        Toast.makeText(this, "Message envoyé à votre contact d'urgence !", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Erreur d'envoi du SMS", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivity(cameraIntent)
    }

    private fun selectContact() {
        val intent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
        startActivityForResult(intent, REQUEST_SELECT_CONTACT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SELECT_CONTACT && resultCode == Activity.RESULT_OK) {
            data?.data?.let { contactUri ->
                val cursor: Cursor? = contentResolver.query(contactUri, null, null, null, null)
                if (cursor != null && cursor.moveToFirst()) {
                    val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    val number = cursor.getString(numberIndex)
                    sharedPreferences.edit().putString("contactNumber", number).apply()
                    Toast.makeText(this, "Contact enregistré : $number", Toast.LENGTH_LONG).show()
                    cursor.close()
                }
            }
        }
    }
}